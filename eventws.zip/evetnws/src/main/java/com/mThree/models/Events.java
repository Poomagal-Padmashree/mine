package com.mThree.models;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Events {
	
	@Id
	private int eventId;
	
	private String eventName;
	
	private String dateOfEvent;
	
	public Events(){}

	public Events(int eventId, String eventName, String dateOfEvent) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.dateOfEvent = dateOfEvent;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getDateOfEvent() {
		return dateOfEvent;
	}

	public void setDateOfEvent(String dateOfEvent) {
		this.dateOfEvent = dateOfEvent;
	}

	@Override
	public String toString() {
		return "Events [eventId=" + eventId + ", eventName=" + eventName + ", dateOfEvent=" + dateOfEvent + "]";
	}
	
	
	
	
}
