package com.mThree.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mThree.models.Events;
import com.mThree.models.Users;
import com.mThree.repositories.eventRepository;
import com.mThree.repositories.userRepository;

@Service
public class eventManagementServices {
	
	@Autowired
	private eventRepository eventRepo;

	@Autowired
	private userRepository userRepo;
	
	public List<Events> allEvents()
	{
		return eventRepo.findAll();
	}
	
	public List<Users> allUsers()
	{
		return userRepo.findAll();
	}

	public Optional<Events> getEventByName(String eventName) {
		System.out.println(eventRepo.findEventsbyEventName(eventName));
		return eventRepo.findEventsbyEventName(eventName);
	}

	public int editEvent(String eventName, String name, String date) {
		return eventRepo.upadteEvent(eventName,name,date);
	}

	public int deleteEventByName(String eventName) {
		
		return eventRepo.deleteEvent(eventName);
	}

	public int deleteUserByName(String userName) {
		// TODO Auto-generated method stub
		return userRepo.deleteUser(userName);
	}

	public void addUser(int id,String name, String event) {
		// TODO Auto-generated method stub
	userRepo.addUser(id,name,event);
	}

	
}
