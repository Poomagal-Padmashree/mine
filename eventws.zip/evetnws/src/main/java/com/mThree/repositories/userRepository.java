package com.mThree.repositories;


import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mThree.models.Users;

@Repository
public interface userRepository extends JpaRepository<Users,Integer>{

	@Query("DELETE from Users WHERE userName=:cUserName")
	@Modifying
	@Transactional
	public int deleteUser(@Param("cUserName")String userName);

	@Query(value="INSERT into users(user_id,user_name,event_name) values(:id,:name,:event)",nativeQuery = true)
	@Modifying
	@Transactional
	public void addUser(@Param("id")int id,@Param("name")String name,@Param("event") String event);

}
