package com.mThree.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mThree.models.Events;
import com.mThree.models.Users;
import com.mThree.services.eventManagementServices;

@RestController
public class eventManagementController {
	
	@Autowired
	private eventManagementServices service;
	
	@GetMapping(path="/events/getAllEvents")
	public List<Events> getAllEvents()
	{
		return service.allEvents();
	}
	
	@GetMapping(path="/events/getAllUsers")
	public List<Users> getAllUsers()
	{
		return service.allUsers();
	}
	
	@GetMapping(path="/events/getIndividualEvent")
	public Optional<Events> getEventsByName(@RequestParam("event")String eventName){
		return service.getEventByName(eventName);
	}
	
	@GetMapping(path="/events/editEvent")
	public int updateEvent(@RequestParam("eventName")String eventName,@RequestParam("name")String name,@RequestParam("date")String date) {
		return service.editEvent(eventName,name,date);
	}
	//localhost:8085/events/editEvent?eventName=dance&name=DANCE&date=12/12/2020
	
	@GetMapping(path="/events/deleteEvent")
	public int deleteEvent(@RequestParam("name")String eventName) {
		System.out.println("eventName");
		return service.deleteEventByName(eventName);
	}
	//localhost:8085/events/deleteEvent?name=Dance
	
	@GetMapping(path="/events/deleteUser")
	public int deleteUser(@RequestParam("name")String userName) {
		System.out.println("userName");
		return service.deleteUserByName(userName);
	}
	//localhost:8085/events/deleteUser?name=Rakshit
	
	@GetMapping(path="/events/addUser")
	public void insertUser(@RequestParam("id")String id,@RequestParam("name")String name,@RequestParam("event")String event) {
		System.out.println(id+" "+name+" "+event);
		service.addUser(Integer.valueOf(id),name,event);
	}
	//localhost:8085/events/addUser?id=2?name=Sahil?event=dance
}
